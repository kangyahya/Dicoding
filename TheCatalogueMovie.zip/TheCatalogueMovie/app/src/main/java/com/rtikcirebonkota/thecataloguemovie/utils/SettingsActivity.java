package com.rtikcirebonkota.thecataloguemovie.utils;

import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.preference.Preference;
import androidx.preference.PreferenceFragmentCompat;
import androidx.preference.SwitchPreference;

import com.rtikcirebonkota.thecataloguemovie.R;
import com.rtikcirebonkota.thecataloguemovie.api.BaseApiService;
import com.rtikcirebonkota.thecataloguemovie.api.RetrofitClient;
import com.rtikcirebonkota.thecataloguemovie.model.MovieResult;
import com.rtikcirebonkota.thecataloguemovie.model.ResponseMovie;
import com.rtikcirebonkota.thecataloguemovie.notification.MovieDailyReceiver;
import com.rtikcirebonkota.thecataloguemovie.notification.MovieUpcomingReceiver;

import org.jetbrains.annotations.NotNull;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import butterknife.BindView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.rtikcirebonkota.thecataloguemovie.utils.Constanta.API_KEY;

public class SettingsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.settings_activity);
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.settings, new SettingsFragment())
                .commit();
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
    }

    public static class SettingsFragment extends PreferenceFragmentCompat implements Preference.OnPreferenceChangeListener {

        SwitchPreference switchReminder;
        SwitchPreference switchToday;

        MovieDailyReceiver movieDailyReceiver = new MovieDailyReceiver();
        MovieUpcomingReceiver movieUpcomingReceiver = new MovieUpcomingReceiver();

        List<MovieResult> movieList;
        List<MovieResult> sameMovieList;
        BaseApiService movieService;
        Call<ResponseMovie> movieCall;
        @Override
        public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {
            setPreferencesFromResource(R.xml.root_preferences, rootKey);
            movieList = new ArrayList<>();
            sameMovieList = new ArrayList<>();
            switchReminder = findPreference(getString(R.string.key_today_reminder));
            switchReminder.setOnPreferenceChangeListener(this);
            switchToday = findPreference(getString(R.string.key_release_reminder));
            switchToday.setOnPreferenceChangeListener(this);
            Preference myPref = findPreference(getString(R.string.key_lang));
            myPref.setOnPreferenceClickListener(preference -> {
                startActivity(new Intent(Settings.ACTION_LOCALE_SETTINGS));
                return true;
            });
        }

        @Override
        public boolean onPreferenceChange(Preference preference, Object newValue) {
            String key = preference.getKey();
            boolean b = (boolean) newValue;

            if(key.equals(getString(R.string.key_today_reminder))){
                if(b){
                    movieDailyReceiver.setAlarm(getActivity());
                }else{
                    movieDailyReceiver.cancelAlarm(getActivity());
                }
            }else{
                if(b){
                    setReleaseAlarm();
                }else{
                    movieUpcomingReceiver.cancelAlarm(getActivity());
                }
            }

            return true;
        }
        private void setReleaseAlarm(){
            movieService = RetrofitClient.getClient().create(BaseApiService.class);
            movieCall = movieService.getUpcomingMovie(API_KEY);

            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
            Date date = new Date();
            final String now = dateFormat.format(date);

            movieCall.enqueue(new Callback<ResponseMovie>() {
                @Override
                public void onResponse(@NotNull Call<ResponseMovie> call, @NotNull Response<ResponseMovie> response) {
                    movieList = response.body().getResults();
                    for(MovieResult movieResult : movieList){
                        if(now.equals(movieResult.getReleaseDate())){
                            sameMovieList.add(movieResult);
                            Log.v("adakah", ""+sameMovieList.size());
                        }
                    }
                    movieUpcomingReceiver.setAlarm(getActivity(), sameMovieList);
                }
                @Override
                public void onFailure(@NotNull Call<ResponseMovie> call, @NotNull Throwable t) {
                    Toast.makeText(getActivity(), "Something went wrong"
                            , Toast.LENGTH_SHORT).show();
                }
            });
        }
    }
}